<?php  
	
	include 'includes/header.html';  
	include 'includes/nav.php';  
?>

    <main class="container">
        <h1>Tema de la página</h1>

    </main>

<?php  include 'includes/footer.php';  ?>